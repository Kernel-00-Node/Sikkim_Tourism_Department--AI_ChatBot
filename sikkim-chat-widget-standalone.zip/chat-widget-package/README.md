# Sikkim Tourism Chat Widget — Standalone Package

This is the minimal file set needed to embed the AI chat widget on its own,
extracted from the full Sikkim Tourism Department project.

## What's included

### Frontend (drop into any React + Tailwind app)
```
frontend/src/components/chat-widget.tsx   ← launcher button + expandable panel
frontend/src/components/chat.tsx          ← chat UI (messages, input, streaming)
frontend/src/components/ui/textarea.tsx
frontend/src/components/ui/scroll-area.tsx
frontend/src/config/brand.ts              ← logo path
frontend/src/config/chat-theme.ts         ← theme colors / prayer-flag motif
frontend/src/hooks/use-typewriter.ts      ← animated bilingual greeting
frontend/src/lib/utils.ts                 ← cn(), withAlpha()
frontend/src/lib/api.ts                   ← createConversation / fetchConversation
frontend/public/images/govt-of-sikkim-logo.png
```

Required npm packages: `react`, `framer-motion`, `lucide-react`,
`react-markdown`, `remark-gfm`, `clsx`, `tailwind-merge`,
`@radix-ui/react-scroll-area`. (See the original `frontend/package.json`
for exact versions.)

### Backend (required — the widget is NOT standalone)
`chat.tsx` calls `/api/conversations` under the hood, so this widget only
works if it's talking to a running instance of the backend:

```
backend/main.py
backend/app/          ← FastAPI routers, RAG chain, vector store, DB layer
backend/requirements.txt
```

Copy `backend/.env.example` → `.env` and fill in the required keys
(DB connection, LLM API key, etc.) before running it.

## Usage

1. Drop the `frontend/src/*` files into your app at matching paths (or
   adjust the `@/...` import aliases to your project's structure).
2. Render `<ChatWidget />` wherever you want the launcher to appear
   (e.g. in your root layout).
3. Deploy `backend/` (or point it at your own existing backend if you're
   re-implementing the API surface) and make sure `/api` is reachable
   from the frontend (same-origin or proxied).

If the goal is a **pure front-end widget with no backend to run**, someone
will need to reimplement `lib/api.ts`'s two functions
(`createConversation`, `fetchConversation`) against whatever chat backend
the Department already has.

/**
 * Standalone demo page — just enough page around the widget so you can
 * see it in isolation. Swap this out for your own site/page and just
 * keep the <ChatWidget /> line when you integrate for real.
 */
import { ChatWidget } from "@/components/chat-widget";

function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
      <div className="text-center max-w-md px-6">
        <h1 className="text-2xl font-semibold mb-2">
          Sikkim Tourism Chat Widget — Standalone Demo
        </h1>
        <p className="text-muted-foreground">
          This page exists only to host the widget for testing. Click the
          launcher in the bottom-right corner to open the chat.
        </p>
      </div>
      <ChatWidget />
    </div>
  );
}

export default App;

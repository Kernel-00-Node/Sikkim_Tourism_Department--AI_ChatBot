/** Application_Entry_Point — standalone widget demo **/

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error(
    "Root mount point #root not found in index.html. " +
      'Ensure <div id="root"></div> exists in the page template.',
  );
}

createRoot(rootElement).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
